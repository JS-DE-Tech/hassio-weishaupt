@echo off
setlocal
cd /d "%~dp0"
echo Starte fokussierten WTC Discovery-Scan Read-Only...
echo.
echo Der Scan kann laenger dauern.
echo Bei einem Abbruch einfach denselben Starter erneut ausfuehren.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0weishaupt-wtc-focused-discovery-readonly.ps1"
echo.
echo Skript beendet.
pause
