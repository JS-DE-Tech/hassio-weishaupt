﻿# ============================================================================
# Weishaupt WTC - fokussierter erweiterter Read-only Discovery-Scan
#
# Ziel:
# - Suche nach bisher nicht erfassten WTC-/WE0-Registern, insbesondere
#   Betriebsstunden, Brennerstarts und weiteren Portalwerten.
#
# Scan-Grenzen:
# - nur bestätigte WTC-Moduladressen:
#     MI=0x07 MX=0x00
#     MI=0x09 MX=0x01
# - OX = 0x2400 bis 0x2AFF
# - OS = 0x00 bis 0x0F
# - VS = 1, 2, 4
#
# Sicherheit:
# - ausschliesslich CM=0x01 GET
# - keine Schreibbefehle
# - Batch-Groesse maximal 6
# - atomarer Checkpoint mit Backup
# ============================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$SystemDevice       = "10.100.1.230"
$Username           = "admin"
$Password           = "Admin123"
$BatchSize          = 6
$DelayMilliseconds  = 150
$MaxTransportRetries = 2
$AbortAfterConsecutiveTransportErrors = 5

$OxStart = 0x2400
$OxEnd   = 0x2AFF
$SubObjectIndices = 0x00..0x0F
$ValueSizes = @(1, 2, 4)

$Modules = @(
    [PSCustomObject]@{ Name = "WTC";           MI = 0x07; MX = 0x00 },
    [PSCustomObject]@{ Name = "WTC_Messmodul"; MI = 0x09; MX = 0x01 }
)

$DesktopPath = [Environment]::GetFolderPath("Desktop")
$OutputDirectory = Join-Path $DesktopPath "weishaupt-wtc-focused-discovery"
$ZipOutput = Join-Path $DesktopPath "weishaupt-wtc-focused-discovery.zip"

$CheckpointFile       = Join-Path $OutputDirectory "checkpoint.json"
$CheckpointBackupFile = Join-Path $OutputDirectory "checkpoint.backup.json"
$CheckpointTempFile   = Join-Path $OutputDirectory "checkpoint.tmp.json"
$HitsCsv              = Join-Path $OutputDirectory "focused-hits.csv"
$RawJsonl              = Join-Path $OutputDirectory "focused-raw-hit-batches.jsonl"
$SummaryTxt            = Join-Path $OutputDirectory "focused-summary.txt"
$ErrorLog              = Join-Path $OutputDirectory "focused-errors.log"

$BaseUrl = "http://$SystemDevice"
$ApiUrl  = "$BaseUrl/ajax/CanApiJson.json"

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

function Make-Visible {
    param([string]$Path)
    if (Test-Path $Path) {
        & attrib.exe -H -S "$Path" 2>$null
        if ((Get-Item $Path).PSIsContainer) {
            Get-ChildItem -LiteralPath $Path -Force -Recurse -ErrorAction SilentlyContinue |
                ForEach-Object { & attrib.exe -H -S $_.FullName 2>$null }
        }
    }
}

function New-GetVg {
    param([PSCustomObject]$Candidate)
    return ("01{0:X2}{1:X2}{2:X4}{3:X2}{4:X4}00" -f `
        $Candidate.MI, $Candidate.MX, $Candidate.OX, $Candidate.OS, $Candidate.VS
    ).ToLowerInvariant()
}

function Save-Checkpoint {
    param([int]$NextIndex)

    [PSCustomObject]@{
        nextIndex = $NextIndex
        updated   = (Get-Date).ToString("o")
    } |
        ConvertTo-Json |
        Set-Content -Path $CheckpointTempFile -Encoding UTF8

    if (Test-Path $CheckpointFile) {
        try {
            if ((Get-Item $CheckpointFile).Length -gt 0) {
                Copy-Item -Path $CheckpointFile -Destination $CheckpointBackupFile -Force
            }
        }
        catch {
            Add-Content -Path $ErrorLog -Value ("{0} Backup warning: {1}" -f (Get-Date).ToString("o"), $_.Exception.Message)
        }
    }

    Move-Item -Path $CheckpointTempFile -Destination $CheckpointFile -Force
}

function Read-Checkpoint {
    foreach ($path in @($CheckpointFile, $CheckpointBackupFile)) {
        if (-not (Test-Path $path)) { continue }

        try {
            if ((Get-Item $path).Length -le 0) { continue }
            $checkpoint = Get-Content -Path $path -Raw | ConvertFrom-Json
            if ($null -ne $checkpoint.nextIndex) { return [int]$checkpoint.nextIndex }
        }
        catch {
            Add-Content -Path $ErrorLog -Value ("{0} Checkpoint read warning: {1}" -f (Get-Date).ToString("o"), $_.Exception.Message)
        }
    }

    return 0
}

function Invoke-JsonPost {
    param([string]$Payload)

    $requestFile = Join-Path $env:TEMP "weishaupt-wtc-focused-request.json"
    [System.IO.File]::WriteAllText($requestFile, $Payload, [System.Text.UTF8Encoding]::new($false))

    $lastError = ""

    for ($attempt = 0; $attempt -le $MaxTransportRetries; $attempt++) {
        try {
            $raw = & curl.exe `
                --http1.1 `
                --silent `
                --show-error `
                --connect-timeout 5 `
                --max-time 20 `
                --user "${Username}:${Password}" `
                --header "Connection: keep-alive" `
                --header "User-Agent:" `
                --header "Accept:" `
                --header "Referer: $BaseUrl/" `
                --header "Content-Type: application/json" `
                --data-binary "@$requestFile" `
                $ApiUrl

            if ($LASTEXITCODE -ne 0) { throw "curl.exe Exit-Code $LASTEXITCODE" }

            $joined = ($raw -join "`n").Trim()
            if ([string]::IsNullOrWhiteSpace($joined)) { throw "Leere Antwort" }

            return $joined
        }
        catch {
            $lastError = $_.Exception.Message
            if ($attempt -lt $MaxTransportRetries) { Start-Sleep -Milliseconds 750 }
        }
    }

    throw $lastError
}

function Build-Candidates {
    $list = New-Object System.Collections.Generic.List[object]

    foreach ($module in $Modules) {
        for ($ox = $OxStart; $ox -le $OxEnd; $ox++) {
            foreach ($os in $SubObjectIndices) {
                foreach ($vs in $ValueSizes) {
                    [void]$list.Add(
                        [PSCustomObject]@{
                            Module = $module.Name
                            MI = [int]$module.MI
                            MX = [int]$module.MX
                            OX = [int]$ox
                            OS = [int]$os
                            VS = [int]$vs
                        }
                    )
                }
            }
        }
    }

    return $list
}

if (-not (Test-Path $HitsCsv)) {
    '"Timestamp";"Module";"MI";"MX";"OX";"OS";"VS";"RequestVG";"ResponseVG";"RawHex";"RawUInt"' |
        Set-Content -Path $HitsCsv -Encoding UTF8
}

$candidates = Build-Candidates
$total = $candidates.Count
$startIndex = Read-Checkpoint
$consecutiveTransportErrors = 0
$started = Get-Date

Write-Host ""
Write-Host "===== WTC FOCUSED DISCOVERY READ-ONLY =====" -ForegroundColor Green
Write-Host "Kandidaten gesamt: $total"
Write-Host "Fortsetzung ab:    $startIndex"
Write-Host "Batch-Groesse:     $BatchSize"
Write-Host "Pause:             $DelayMilliseconds ms"
Write-Host ""
Write-Host "Nur GET-Abfragen. Keine Schreibbefehle." -ForegroundColor Yellow

try {
    for ($offset = $startIndex; $offset -lt $total; $offset += $BatchSize) {
        $last = [Math]::Min($offset + $BatchSize - 1, $total - 1)
        $batch = @($candidates[$offset..$last])
        $capi = [ordered]@{ NN = $batch.Count }

        for ($index = 0; $index -lt $batch.Count; $index++) {
            $key = "N{0:D2}" -f ($index + 1)
            $capi[$key] = @{ VG = New-GetVg -Candidate $batch[$index] }
        }

        $request = [ordered]@{ ID = "12345678"; SRC = "DDC"; CAPI = $capi }

        try {
            $raw = Invoke-JsonPost -Payload ($request | ConvertTo-Json -Depth 8 -Compress)
            $response = $raw | ConvertFrom-Json
            $consecutiveTransportErrors = 0
        }
        catch {
            $consecutiveTransportErrors++
            Add-Content -Path $ErrorLog -Value ("{0} Batch {1}-{2}: {3}" -f (Get-Date).ToString("o"), ($offset + 1), ($last + 1), $_.Exception.Message)

            if ($consecutiveTransportErrors -ge $AbortAfterConsecutiveTransportErrors) {
                throw "Abbruch nach $consecutiveTransportErrors aufeinanderfolgenden Transportfehlern."
            }

            Save-Checkpoint -NextIndex $offset
            Start-Sleep -Milliseconds 1000
            continue
        }

        for ($index = 0; $index -lt $batch.Count; $index++) {
            $candidate = $batch[$index]
            $key = "N{0:D2}" -f ($index + 1)
            $property = $response.CAPI.PSObject.Properties[$key]
            if ($null -eq $property) { continue }

            $vg = [string]$property.Value.VG
            if ([string]::IsNullOrWhiteSpace($vg) -or $vg.Length -lt 16) { continue }

            $cmd = [Convert]::ToInt32($vg.Substring(0, 2), 16)
            if ($cmd -ne 0x02) { continue }

            $rawHex = $vg.Substring(16)
            $rawUInt = ""

            try { $rawUInt = [Convert]::ToUInt64($rawHex, 16) } catch { $rawUInt = "" }

            $line = @(
                (Get-Date).ToString("s"),
                $candidate.Module,
                ("0x{0:X2}" -f $candidate.MI),
                ("0x{0:X2}" -f $candidate.MX),
                ("0x{0:X4}" -f $candidate.OX),
                ("0x{0:X2}" -f $candidate.OS),
                $candidate.VS,
                $capi[$key].VG,
                $vg,
                $rawHex,
                $rawUInt
            ) | ForEach-Object { '"' + ([string]$_ -replace '"', '""') + '"' }

            ($line -join ";") | Add-Content -Path $HitsCsv -Encoding UTF8
        }

        [PSCustomObject]@{
            timestamp = (Get-Date).ToString("o")
            request = $request
            response = $response
        } |
            ConvertTo-Json -Depth 12 -Compress |
            Add-Content -Path $RawJsonl -Encoding UTF8

        Save-Checkpoint -NextIndex ($last + 1)

        if ((($offset / $BatchSize) % 100) -eq 0 -or $last -eq ($total - 1)) {
            $percent = [Math]::Round((($last + 1) / $total) * 100, 1)
            Write-Host ("Fortschritt: {0,6}% | {1}/{2}" -f $percent, ($last + 1), $total)
        }

        Start-Sleep -Milliseconds $DelayMilliseconds
    }
}
catch {
    Write-Host ""
    Write-Host "SCAN UNTERBROCHEN:" -ForegroundColor Yellow
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host "Fortschritt bleibt gespeichert. Starter erneut ausfuehren." -ForegroundColor Yellow
    Make-Visible -Path $OutputDirectory
    Start-Process explorer.exe -ArgumentList "`"$OutputDirectory`""
    exit 1
}

$finished = Get-Date
$duration = New-TimeSpan -Start $started -End $finished

@"
===== WTC FOCUSED DISCOVERY SUMMARY =====
Start:                $($started.ToString("s"))
Ende:                 $($finished.ToString("s"))
Laufzeit:             $($duration.ToString())
Kandidaten:           $total
OX-Bereich:           0x$('{0:X4}' -f $OxStart) bis 0x$('{0:X4}' -f $OxEnd)
OS-Bereich:           0x00 bis 0x0F
VS-Werte:             1, 2, 4
Batch-Groesse:        $BatchSize
Pause pro Request:    $DelayMilliseconds ms
"@ | Set-Content -Path $SummaryTxt -Encoding UTF8

Remove-Item $CheckpointFile, $CheckpointBackupFile, $CheckpointTempFile -ErrorAction SilentlyContinue

Make-Visible -Path $OutputDirectory

if (Test-Path $ZipOutput) { Remove-Item $ZipOutput -Force }
Compress-Archive -Path (Join-Path $OutputDirectory "*") -DestinationPath $ZipOutput -Force
Make-Visible -Path $ZipOutput

Write-Host ""
Write-Host "===== FERTIG =====" -ForegroundColor Green
Write-Host "ZIP-Datei:"
Write-Host "  $ZipOutput"
Write-Host ""
Write-Host "Bitte diese ZIP-Datei hochladen." -ForegroundColor Green

Start-Process explorer.exe -ArgumentList "`"$OutputDirectory`""
