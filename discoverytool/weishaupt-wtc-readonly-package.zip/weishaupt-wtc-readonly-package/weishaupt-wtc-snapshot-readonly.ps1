﻿# ============================================================================
# Weishaupt WTC / Portal - erweiterter Read-only Snapshot
#
# Dieses Skript sendet ausschliesslich GET-Abfragen (CM=0x01).
# Es erzeugt keine Schreibbefehle und aendert keine Einstellungen.
#
# Enthalten:
# - kuratierte, bestaetigte WTC- und Systemwerte
# - plausible WTC-Arbeitskandidaten aus den Portal-Screenshots
# - alle 600 nativen WTC-Antwortobjekte aus dem ersten Discovery-Scan
#   als Rohwertkatalog fuer den aktuellen Zustand
#
# Batch-Groesse = 6, da dies fuer das getestete Systemgeraet bestaetigt wurde.
# ============================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$SystemDevice      = "10.100.1.230"
$Username          = "admin"
$Password          = "Admin123"
$BatchSize         = 6
$DelayMilliseconds = 120

$DesktopPath     = [Environment]::GetFolderPath("Desktop")
$OutputDirectory = Join-Path $DesktopPath "weishaupt-wtc-snapshot"
$ZipOutput       = Join-Path $DesktopPath "weishaupt-wtc-snapshot.zip"
$BaseUrl         = "http://$SystemDevice"
$ApiUrl          = "$BaseUrl/ajax/CanApiJson.json"

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

function Make-Visible {
    param([string]$Path)

    if (Test-Path $Path) {
        & attrib.exe -H -S "$Path" 2>$null
        if ((Get-Item $Path).PSIsContainer) {
            Get-ChildItem -LiteralPath $Path -Force -Recurse -ErrorAction SilentlyContinue |
                ForEach-Object { & attrib.exe -H -S $_.FullName 2>$null }
        }
    }
}

function Convert-HexToUnsigned {
    param([string]$HexValue)
    if ([string]::IsNullOrWhiteSpace($HexValue)) { return $null }
    try { return [Convert]::ToUInt64($HexValue, 16) } catch { return $null }
}

function Convert-HexToSigned {
    param([string]$HexValue, [int]$ByteCount)
    if ([string]::IsNullOrWhiteSpace($HexValue)) { return $null }

    try {
        $unsigned = [Convert]::ToUInt64($HexValue, 16)
        $bits = $ByteCount * 8
        $signBit = [UInt64]1 -shl ($bits - 1)
        if (($unsigned -band $signBit) -ne 0) {
            return [Int64]($unsigned - [Math]::Pow(2, $bits))
        }
        return [Int64]$unsigned
    }
    catch {
        return $null
    }
}

function Test-Sentinel {
    param([string]$HexValue)
    if ([string]::IsNullOrWhiteSpace($HexValue)) { return $false }

    switch ($HexValue.ToLowerInvariant()) {
        "8000" { return $true }
        "ffff" { return $true }
        "80000000" { return $true }
        "ffffffff" { return $true }
        default { return $false }
    }
}

function New-GetVg {
    param([PSCustomObject]$Candidate)

    $mi = [Convert]::ToInt32(([string]$Candidate.MI).Replace("0x", ""), 16)
    $mx = [Convert]::ToInt32(([string]$Candidate.MX).Replace("0x", ""), 16)
    $ox = [Convert]::ToInt32(([string]$Candidate.OX).Replace("0x", ""), 16)
    $os = [Convert]::ToInt32(([string]$Candidate.OS).Replace("0x", ""), 16)
    $vs = [int]$Candidate.VS

    return ("01{0:X2}{1:X2}{2:X4}{3:X2}{4:X4}00" -f $mi, $mx, $ox, $os, $vs).ToLowerInvariant()
}

function Invoke-JsonPost {
    param([string]$Payload)

    $requestFile = Join-Path $env:TEMP "weishaupt-wtc-snapshot-request.json"
    [System.IO.File]::WriteAllText($requestFile, $Payload, [System.Text.UTF8Encoding]::new($false))

    $raw = & curl.exe `
        --http1.1 `
        --silent `
        --show-error `
        --connect-timeout 5 `
        --max-time 20 `
        --user "${Username}:${Password}" `
        --header "Connection: keep-alive" `
        --header "User-Agent:" `
        --header "Accept:" `
        --header "Referer: $BaseUrl/" `
        --header "Content-Type: application/json" `
        --data-binary "@$requestFile" `
        $ApiUrl

    if ($LASTEXITCODE -ne 0) {
        throw "curl.exe POST fehlgeschlagen. Exit-Code: $LASTEXITCODE"
    }

    $joined = ($raw -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($joined)) {
        throw "Leere Antwort vom Systemgeraet."
    }

    return $joined
}

function Expand-EmbeddedCatalog {
    param([string]$Base64Data, [string]$TargetPath)

    $bytes = [Convert]::FromBase64String(($Base64Data -replace '\s', ''))
    $memory = New-Object System.IO.MemoryStream(,$bytes)
    $gzip = New-Object System.IO.Compression.GzipStream(
        $memory,
        [System.IO.Compression.CompressionMode]::Decompress
    )
    $reader = New-Object System.IO.StreamReader($gzip, [System.Text.Encoding]::UTF8)
    $csv = $reader.ReadToEnd()

    $reader.Dispose()
    $gzip.Dispose()
    $memory.Dispose()

    [System.IO.File]::WriteAllText($TargetPath, $csv, [System.Text.UTF8Encoding]::new($true))
    return @(Import-Csv -Path $TargetPath -Delimiter ";")
}

function Add-CuratedCandidate {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Category,
        [string]$Name,
        [string]$MI,
        [string]$MX,
        [string]$OX,
        [string]$OS,
        [int]$VS,
        [string]$Confidence,
        [string]$Notes = ""
    )

    [void]$List.Add(
        [PSCustomObject]@{
            Module     = $Category
            Name       = $Name
            MI         = $MI
            MX         = $MX
            OX         = $OX
            OS         = $OS
            VS         = $VS
            Confidence = $Confidence
            Notes      = $Notes
        }
    )
}

function Invoke-Capture {
    param(
        [array]$Candidates,
        [string]$OutputCsv,
        [string]$RawJsonl
    )

    $rows = New-Object System.Collections.Generic.List[object]

    for ($offset = 0; $offset -lt $Candidates.Count; $offset += $BatchSize) {
        $last = [Math]::Min($offset + $BatchSize - 1, $Candidates.Count - 1)
        $batch = @($Candidates[$offset..$last])

        $capi = [ordered]@{ NN = $batch.Count }

        for ($index = 0; $index -lt $batch.Count; $index++) {
            $key = "N{0:D2}" -f ($index + 1)
            $capi[$key] = @{ VG = New-GetVg -Candidate $batch[$index] }
        }

        $request = [ordered]@{
            ID   = "12345678"
            SRC  = "DDC"
            CAPI = $capi
        }

        try {
            $raw = Invoke-JsonPost -Payload ($request | ConvertTo-Json -Depth 8 -Compress)
            $response = $raw | ConvertFrom-Json

            [PSCustomObject]@{
                timestamp = (Get-Date).ToString("o")
                request   = $request
                response  = $response
            } |
                ConvertTo-Json -Depth 12 -Compress |
                Add-Content -Path $RawJsonl -Encoding UTF8
        }
        catch {
            Write-Host ("Batch {0}-{1} fehlgeschlagen: {2}" -f ($offset + 1), ($last + 1), $_.Exception.Message) -ForegroundColor Red
            Start-Sleep -Milliseconds $DelayMilliseconds
            continue
        }

        for ($index = 0; $index -lt $batch.Count; $index++) {
            $candidate = $batch[$index]
            $key = "N{0:D2}" -f ($index + 1)
            $property = $response.CAPI.PSObject.Properties[$key]

            if ($null -eq $property) { continue }

            $vg = [string]$property.Value.VG
            if ([string]::IsNullOrWhiteSpace($vg) -or $vg.Length -lt 16) { continue }

            $cmd = [Convert]::ToInt32($vg.Substring(0, 2), 16)
            if ($cmd -ne 0x02) { continue }

            $vs = [Convert]::ToInt32($vg.Substring(12, 4), 16)
            $rawHex = $vg.Substring(16)

            [void]$rows.Add(
                [PSCustomObject]@{
                    Timestamp  = (Get-Date).ToString("s")
                    Module     = [string]$candidate.Module
                    Name       = [string]$candidate.Name
                    Confidence = [string]$candidate.Confidence
                    Notes      = [string]$candidate.Notes
                    MI         = ("0x{0:X2}" -f [Convert]::ToInt32($vg.Substring(2, 2), 16))
                    MX         = ("0x{0:X2}" -f [Convert]::ToInt32($vg.Substring(4, 2), 16))
                    OX         = ("0x{0:X4}" -f [Convert]::ToInt32($vg.Substring(6, 4), 16))
                    OS         = ("0x{0:X2}" -f [Convert]::ToInt32($vg.Substring(10, 2), 16))
                    VS         = $vs
                    RawHex     = $rawHex
                    RawUInt    = Convert-HexToUnsigned -HexValue $rawHex
                    RawSigned  = Convert-HexToSigned -HexValue $rawHex -ByteCount $vs
                    ValueX01   = if ($null -ne (Convert-HexToSigned -HexValue $rawHex -ByteCount $vs)) { [Math]::Round(((Convert-HexToSigned -HexValue $rawHex -ByteCount $vs) / 10.0), 3) } else { "" }
                    ValueX001  = if ($null -ne (Convert-HexToSigned -HexValue $rawHex -ByteCount $vs)) { [Math]::Round(((Convert-HexToSigned -HexValue $rawHex -ByteCount $vs) / 100.0), 3) } else { "" }
                    Sentinel   = Test-Sentinel -HexValue $rawHex
                    RequestVG  = $capi[$key].VG
                    ResponseVG = $vg
                }
            )
        }

        if ((($offset / $BatchSize) % 50) -eq 0 -or $last -eq ($Candidates.Count - 1)) {
            $percent = [Math]::Round((($last + 1) / $Candidates.Count) * 100, 1)
            Write-Host ("Fortschritt: {0,6} % | {1} / {2}" -f $percent, ($last + 1), $Candidates.Count)
        }

        Start-Sleep -Milliseconds $DelayMilliseconds
    }

    $rows | Export-Csv -Path $OutputCsv -Delimiter ";" -NoTypeInformation -Encoding UTF8
}

$Curated = New-Object System.Collections.Generic.List[object]

# --------------------------------------------------------------------------
# Bestaetigte Standardwerte
# --------------------------------------------------------------------------
Add-CuratedCandidate $Curated "System" "Systembetriebsart" "0x01" "0x00" "0x261E" "0x00" 1 "CONFIRMED"
Add-CuratedCandidate $Curated "System" "Aussentemperatur aktuell" "0x01" "0x00" "0x26B1" "0x02" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "System" "Waermeanforderung Heizung" "0x01" "0x00" "0x259C" "0x01" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "System" "Waermeanforderung Warmwasser" "0x01" "0x00" "0x259D" "0x01" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "Hydraulik" "Plattenwaermetauschertemperatur" "0x01" "0x00" "0x261F" "0x02" 2 "CONFIRMED"

Add-CuratedCandidate $Curated "WTC" "Betriebsphase WTC" "0x09" "0x01" "0x2639" "0x00" 1 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Betriebsphase Brenner" "0x07" "0x00" "0x2541" "0x00" 1 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Vorlaufsolltemperatur" "0x07" "0x00" "0x2545" "0x00" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Kesseltemperatur" "0x07" "0x00" "0x2532" "0x00" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Abgastemperatur empirisch" "0x07" "0x00" "0x2533" "0x02" 2 "CONFIRMED_EMPIRICAL"
Add-CuratedCandidate $Curated "WTC" "Ruecklauftemperatur empirisch" "0x07" "0x00" "0x2537" "0x00" 2 "CONFIRMED_EMPIRICAL"
Add-CuratedCandidate $Curated "WTC" "Volumenstrom VPT" "0x09" "0x01" "0x2613" "0x02" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Anlagendruck VPT" "0x09" "0x01" "0x2614" "0x02" 2 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Waermeleistung VPT" "0x09" "0x01" "0x2631" "0x02" 4 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Tageswaermemenge Vortag Heizbetrieb" "0x09" "0x01" "0x2626" "0x02" 4 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Tageswaermemenge Vortag Warmwasser" "0x09" "0x01" "0x2627" "0x02" 4 "CONFIRMED"
Add-CuratedCandidate $Curated "WTC" "Tageswaermemenge Vortag Gesamt" "0x09" "0x01" "0x2628" "0x02" 4 "CONFIRMED"

# --------------------------------------------------------------------------
# Portal-Screenshot-Arbeitskandidaten
# Diese Werte werden bewusst als Kandidaten exportiert.
# --------------------------------------------------------------------------
Add-CuratedCandidate $Curated "WTC Kandidat" "Istleistung aktuell Prozent" "0x09" "0x01" "0x2619" "0x02" 1 "INFERRED_MEDIUM" "Portal zeigt 0 Prozent; Zuordnung noch bestaetigen"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 2610" "0x09" "0x01" "0x2610" "0x02" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 2611" "0x09" "0x01" "0x2611" "0x02" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 2612" "0x09" "0x01" "0x2612" "0x02" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 2615" "0x09" "0x01" "0x2615" "0x02" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 263A" "0x09" "0x01" "0x263A" "0x02" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 2679" "0x09" "0x01" "0x2679" "0x00" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268A" "0x09" "0x01" "0x268A" "0x00" 4 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268B" "0x09" "0x01" "0x268B" "0x00" 4 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268C" "0x09" "0x01" "0x268C" "0x00" 4 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268D" "0x09" "0x01" "0x268D" "0x00" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268E" "0x09" "0x01" "0x268E" "0x00" 2 "INFERRED_MEDIUM"
Add-CuratedCandidate $Curated "WTC Kandidat" "Dynamischer Wert 268F" "0x09" "0x01" "0x268F" "0x00" 2 "INFERRED_MEDIUM"

$CatalogBase64 = @'
H4sIAMuNKWoC/5Wc3W4bNxCF7/sUfgRxSA650JV+2yJwWySB07tCSbaOEcsOJLkp+vS1s7ITAd7Dz0CgGJlZ8ZA7M+dwSOf89uPddT89/3V6/uf09/s/b6YX
b6avbm6/3vy22fY/vXu7mE7+nZSHj8n9h+Vvf91/2PQ5Yxh+Ds8aTRlj0xhGxvxmNGVMI8akppKV0ZVxpqYyV8aFMi6bxrEVWqoVWqoVWqkx103jGKD1AEg8
mZ43hokYczCOjDkYTRlHFiGooB6MQT1pyjg2psqVEEX0haSeTAptUmiTQutqTFdjuoiEwTgWCUUtQlXGTqGdqSdV8oaFenKpjCtlXAujqWJsQRlNGVUxNlWM
TRVjU8XYVDE2VYxNRZ+p6DNXaF2hVdFnVQGqClBVgKoC1ClAKqhNBbWpoDYV1KaC2lRQR1Xj4zGo07PGp6B+1e/3/fWh337pd5vD3e45ZxXkUQV5fAry1/3l
1f7Q786Cl7N/+t327nB99eHT2ez95WYPRh95mVHlQswKd1a4s4iuqCRNfAr3H2Zcf5zx67v+w+frzd3fetYqM6Kqy1GJqjhvGseWZC74ZzCO8E9UWm0wjo25
UGMu1Jgq4aLKqaSIIj0JnHl/2F317/dfPm32/dl819/c9M+9x6TYIykFkp4q+cXt7iFe9rfXOk+TCsyk6nBSKiArhZVT0zjycnMSLzcn8XKzyuusFiErIe6q
mnpoGkfm6UHM04OYp6uFH4xjY5qoX4NxpKC6qvWuqq2rt+Kq2rqqtoNxDK162V4UoKIAFQWoKEAqkVyV7cEY1JOmjGOAFBsMxqCeNGUcG1ORjCuScUUyrkjG
Fcm4IhlXJOOKZFz1GVz1GXypxlyqMVWfYTCOjblSY67EmEXVvqKKVElN4wjaotihKHYoKu2Lys+i8rOoRCoq4ovaGRQlVIraGVRFV1U1eOpErG2diLWtKhKq
YsGqWLAqFqwqwKpiwWpqTFNjqritKm6rituq4rYq/qyKP6viz6r4s6pdRlX771rVPKuap0qkqhipztSYMzWmys+qGKkqRqqKkapipLpsGscAKeqoijqqoo6q
lHGnSk2nakKnkrdLTePIInQqyzqVZZ2KhE5FQqcioVOR0Ika7xOxtkdjUE+aejIpYx4xBgUoKEBBATpGQp48a41q0KSMWRmLWvkTLfDXeb/fbx8O+R7+9SjG
fzzGC8QtsG8z9m2JueWmW2BTCGwKgU3h9IWP+0UGLjG3zNwKe/coRJyFiLPX4Kenvw230MRm5G0d3VLTLTJs6QVu7SkkNoXEppAZtsywZYYtM2zOsDnD5gyb
M2yFYSsMW2HYCsNWGbaOuc2Y2/wFbu0FmbMFmbMFWTBsC4ZtwbAtGLYlw7Zk2E6ubDTcUtNtxbCtGLYVw7Zi2NYM25phWzNsa4QtMAYMSCT56Q2UhlsbG6Pd
EBi2wLAFho1xfWBcH4xhM4aNcX2IDNvTUfDF7fXdtr/ZH3a327OLP96Cx9pYmeAITHB8v98zu7neXPY3H3d3Hz6DR9o4mfgITHyEzN53ZtiY+AhMfAQmPgIT
H4GJj8DER2DiIzDxEZiqCB3D1jFsHcPGpEyYMWwzhm3GsDH9FJh+Ckw/BaafAtNPgUmZwFRFWL/Arb0ga7Yga7QgxgjeGMEb6oIc3drYGIkaI1FjG2ZjG2Zj
JGqMRB8vDaJva2NjpGmMNI3t0o3t0o0RpTGiNLZLN7ZLN0aUxojy8Wplmr69lxr7r5t+t+3v9dFlf3ZxuztsLs9+6a/+ez/cNwLflI43/sbdGJca41IrLfjv
Nrvt181+P9yPanxRGz3b6p9eHm24KfQ/9/vN9gC+pI2c6QRjOsE6pP2sQ9rPmE4wphOM6QRjOsGYTjCmE4zpBGM6wZhOMNZnMdZnMdZnMSZOjPVZbMmwLRk2
poiM9VlsxbCtGDYmw4zJMGMyzJgMi0yGRSbDIpNhkcmwyPoskfVZIuuzRNZniUwiRiYRI5OIkUnEyGRYZDIsJrZurF/xeA29QW3fL6Sf3ou+f0Y/x2gnMtqJ
Mzb1GZs6o53IaOfx+jxya2NjpT2y0h5ZaY+stEdWPiMrn5G1qSNrUydWPlNAx76nd/vH3SJzY2Ug5Re4BeZmzC0xt9x0Y0I4MSGcWMMssYZZYhUpsYqUmBBO
TAgnVpESq0iJVaTEKlJiQjgxIZwWDNuCYWPVMrFqmdiBY2IHjokJ4bR+gVt7CkyTJqZJMyuqmWnSzDRpZpo0M02amSbNgWELDBvTpJlp0sw0aWaaNLO2ZWZt
yxxRymR21pcZUWamlzNrW2bWtsyMnTNrW2bGzpmxc2Zty8zaltnZO3X2TpkkyEwSZCYJMpMEzuqbs/rmrL45q2/OaojHF7i1p8BOIZydQjhLZ2fp7CydnaWz
s3R2ls7O0tlZOjtLZ2fp7Oy43tlxvbMjBmdHDM6O650d1zu70+sdc2P7BWf7BWf7BWf7BWf7BWf7BWf7BWf7BWf7BV+9wK09BXYfz9l9PGea3Jkmd9bocNbo
KIyzypGzEnGzphsjo8IEbWGCtjBBWxjLFMYyhbFMYSxTWCUvrJIXVskLq+SFHbcWdtxaKsNWGTZWosuMuc2Z24K5LZkbq2+F1bfCzsEKOwerEzSFypqllRWH
yopDZcWhsuJQmTyumc3UmRvLrMdfl23U3sffcG25LZgbi966Ym7f/7+d/wH7kX3uRlMAAA==
'@

$CatalogPath = Join-Path $OutputDirectory "wtc-native-catalog.csv"
$CuratedCsv = Join-Path $OutputDirectory "curated-values.csv"
$CuratedRaw = Join-Path $OutputDirectory "curated-raw.jsonl"
$AllNativeCsv = Join-Path $OutputDirectory "all-native-wtc-values.csv"
$AllNativeRaw = Join-Path $OutputDirectory "all-native-wtc-raw.jsonl"
$PortalChecklist = Join-Path $OutputDirectory "portal-parameter-checklist.csv"

[System.IO.File]::WriteAllText(
    $PortalChecklist,
    @'
Bereich;Portalparameter;Status
System;Status / Systembetriebsart;CONFIRMED
System;Aussentemperatur aktuell;CONFIRMED
System;Aussentemperatur gedaempft;OPEN
System;Aussentemperatur gemischt;OPEN
System;Aussentemperatur Minimum;INFERRED_HIGH
System;Aussentemperatur Maximum;INFERRED_HIGH
System;Aussentemperatur ruecksetzen;INFERRED_MEDIUM
System;Waermeanforderung Heizung aktuell;CONFIRMED
System;Waermeanforderung Heizkreis HK1;OPEN
System;Waermeanforderung Heizkreis HK2;OPEN
System;Waermeanforderung Heizkreis HK3;OPEN
System;Waermeanforderung Warmwasser aktuell;CONFIRMED
System;Vorlaufsolltemperatur Warmwasser aktuell;OPEN
Hydraulik;Plattenwaermetauschertemperatur aktuell;CONFIRMED
WTC WE0;Betriebsphase WTC;CONFIRMED
WTC WE0;Betriebsphase Brenner;CONFIRMED
WTC WE0;Sollleistung aktuell;OPEN
WTC WE0;Istleistung aktuell;INFERRED_MEDIUM
WTC WE0;Vorlaufsolltemperatur aktuell;CONFIRMED
WTC WE0;Vorlauftemperatur aktuell;OPEN
WTC WE0;Vorlauftemperatur VPT aktuell;OPEN
WTC WE0;Ruecklauftemperatur VPT aktuell;CONFIRMED
WTC WE0;Abgastemperatur aktuell;CONFIRMED_EMPIRICAL
WTC WE0;Tageswaermemenge Vortag Gesamt;CONFIRMED
WTC WE0;Tageswaermemenge Vortag Heizbetrieb;CONFIRMED
WTC WE0;Tageswaermemenge Vortag Warmwasserbetrieb;CONFIRMED
WTC WE0;Zaehler seit Ruecksetzen Brennerstarts;OPEN
WTC WE0;Zaehler seit Ruecksetzen Betriebsstunden;OPEN
WTC WE0;Zaehler seit Ruecksetzen Ruecksetzen;OPEN
WTC WE0;Gesamtzaehler Brennerstarts;OPEN
WTC WE0;Gesamtzaehler Betriebsstunden;OPEN
WTC WE0;Dreiwegeventil intern;OPEN
WTC WE0;Pumpenleistung Sollstellung;OPEN
WTC WE0;Pumpenleistung elektrische Leistung;OPEN
WTC WE0;Pumpenleistung Betriebsart;OPEN
WTC WE0;Volumenstrom VPT aktuell;CONFIRMED
WTC WE0;Waermeleistung VPT aktuell;CONFIRMED
WTC WE0;Anlagendruck VPT aktuell;CONFIRMED
WTC WE0;Ionisationssignal SCOT-Basiswert;OPEN
WTC WE0;Ionisationssignal Sollwert;OPEN
WTC WE0;Ionisationssignal SCOT-Istwert;OPEN
WTC WE0;Ionisationssignal Start aktuell;OPEN
WTC WE0;Gasventil Offset aktuell;OPEN
WTC WE0;Zeit bis Flammenbildung aktuell;OPEN
WTC WE0;Gasventil Ansteuersignal aktuell;OPEN
WTC WE0;Gas-Luft-Verhaeltnis aktuell;OPEN
WTC WE0;Geblaesedrehzahl aktuell;OPEN
WTC WE0;Geblaese-Ansteuersignal aktuell;OPEN
WTC WE0;Gasdruck aktuell;OPEN
HK1;Betriebsart / Status / Temperaturen / Pumpe / Aufheizoptimierung;PARTIAL
HK2;Betriebsart / Status / Temperaturen / Mischer / Pumpe / Aufheizoptimierung;PARTIAL
HK3;Betriebsart / Status / Temperaturen / Pumpe / Aufheizoptimierung;PARTIAL
Warmwasser;Status / Solltemperatur / Isttemperatur / Pumpe / Status WW;PARTIAL
Fehlerspeicher;System / WTC / HK1 / HK2 / HK3;OPEN

'@,
    [System.Text.UTF8Encoding]::new($true)
)

Make-Visible -Path $OutputDirectory

Write-Host ""
Write-Host "===== WEISHAUPT WTC SNAPSHOT READ-ONLY =====" -ForegroundColor Green
Write-Host "Systemgeraet: $SystemDevice"
Write-Host "Ausgabe:      $OutputDirectory"
Write-Host ""
Write-Host "Es werden ausschliesslich GET-Abfragen gesendet." -ForegroundColor Yellow
Write-Host ""

Write-Host "1/2 Kuratierte Werte und Portal-Kandidaten ..." -ForegroundColor Cyan
Invoke-Capture -Candidates @($Curated) -OutputCsv $CuratedCsv -RawJsonl $CuratedRaw

Write-Host ""
Write-Host "2/2 Alle bereits entdeckten nativen WTC-Objekte ..." -ForegroundColor Cyan
$NativeCatalog = Expand-EmbeddedCatalog -Base64Data $CatalogBase64 -TargetPath $CatalogPath

$NativeCandidates = foreach ($row in $NativeCatalog) {
    [PSCustomObject]@{
        Module     = [string]$row.Module
        Name       = [string]$row.KnownName
        MI         = [string]$row.MI
        MX         = [string]$row.MX
        OX         = [string]$row.OX
        OS         = [string]$row.OS
        VS         = [int]$row.VS
        Confidence = "RAW_NATIVE"
        Notes      = "Aus erstem Discovery-Scan"
    }
}

Invoke-Capture -Candidates @($NativeCandidates) -OutputCsv $AllNativeCsv -RawJsonl $AllNativeRaw

Make-Visible -Path $OutputDirectory

if (Test-Path $ZipOutput) { Remove-Item $ZipOutput -Force }
Compress-Archive -Path (Join-Path $OutputDirectory "*") -DestinationPath $ZipOutput -Force
Make-Visible -Path $ZipOutput

Write-Host ""
Write-Host "===== FERTIG =====" -ForegroundColor Green
Write-Host "ZIP-Datei:"
Write-Host "  $ZipOutput"
Write-Host ""
Write-Host "Bitte diese ZIP-Datei hochladen." -ForegroundColor Green

Start-Process explorer.exe -ArgumentList "`"$OutputDirectory`""
