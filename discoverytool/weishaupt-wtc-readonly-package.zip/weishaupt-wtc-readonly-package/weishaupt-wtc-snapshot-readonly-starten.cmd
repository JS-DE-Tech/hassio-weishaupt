@echo off
setlocal
cd /d "%~dp0"
echo Starte Weishaupt WTC Snapshot Read-Only...
echo.
echo Voraussetzung:
echo - Cloud-Verbindung deaktiviert
echo - lokale JSON-Schnittstelle aktiviert
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0weishaupt-wtc-snapshot-readonly.ps1"
echo.
echo Skript beendet.
pause
