@echo off
setlocal
cd /d "%~dp0"

echo Starte Weishaupt Read-Only Discovery Scan v3...
echo.
echo Das Skript verwendet atomare Checkpoints mit Backup.
echo Falls eine Checkpoint-Datei unlesbar ist, wird automatisch aus der
echo vorhandenen discovery-hits.csv weitergemacht.
echo.
echo Das Fenster bitte nicht schliessen.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0weishaupt-readonly-discovery-v3.ps1"

echo.
echo Discovery-Skript beendet.
pause
