﻿# ============================================================================
# Weishaupt CanApiJson structured read-only discovery scan - v3
#
# This script only sends read requests:
#   CM = 0x01  GET numeric value
#
# It never sends:
#   CM = 0x03  SET
#   CM = 0x13  SETS
#
# The scan is deliberately rate-limited and uses no more than six VG frames
# per request. The tested Systemgeraet returned CMD_ERROR for frames 7-10 in
# larger batches.
#
# Run this script with the supplied CMD starter. Do not paste it into an
# interactive PowerShell window.
# ============================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================================
# Configuration
# ============================================================================

$SystemDevice       = "10.100.1.230"
$Username           = "admin"
$Password           = "Admin123"

# Confirmed safe limit for the tested device
$BatchSize          = 6

# Delay after every HTTP request. Increase this value if the device reacts
# slowly. The default scan normally takes roughly 25-45 minutes.
$DelayMilliseconds  = 175

# Retry only transport-level failures. CMD_ERROR responses are expected for
# many unknown objects and are not retried.
$MaxTransportRetries = 2
$AbortAfterConsecutiveTransportErrors = 5

# Stage-1 discovery range:
# Most known CanApiJson objects are located between 0x2500 and 0x26FF.
$OxStart = 0x2500
$OxEnd   = 0x26FF

# Probe common sub-object indices and value sizes only.
$SubObjectIndices = @(0x00, 0x01, 0x02, 0x04, 0x05)
$ValueSizes       = @(1, 2, 4)

# Only scan module addresses already confirmed on this installation.
$Modules = @(
    [PSCustomObject]@{ Name = "Systemgeraet";     MI = 0x01; MX = 0x00 },
    [PSCustomObject]@{ Name = "HK1";              MI = 0x02; MX = 0x00 },
    [PSCustomObject]@{ Name = "HK2_Fussboden";    MI = 0x02; MX = 0x01 },
    [PSCustomObject]@{ Name = "HK3_Heizkoerper";  MI = 0x02; MX = 0x02 },
    [PSCustomObject]@{ Name = "Warmwasser";       MI = 0x03; MX = 0x00 },
    [PSCustomObject]@{ Name = "Gateway_Netzwerk"; MI = 0x06; MX = 0x00 },
    [PSCustomObject]@{ Name = "WTC";              MI = 0x07; MX = 0x00 },
    [PSCustomObject]@{ Name = "WTC_Messmodul";    MI = 0x09; MX = 0x01 }
)

$DesktopPath = [Environment]::GetFolderPath("Desktop")
$OutputDirectory = Join-Path $DesktopPath "weishaupt-discovery"
$ZipOutput       = Join-Path $DesktopPath "weishaupt-discovery.zip"

$BaseUrl = "http://$SystemDevice"
$ApiUrl  = "$BaseUrl/ajax/CanApiJson.json"

# ============================================================================
# Output files
# ============================================================================

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
& attrib.exe -H -S "$OutputDirectory" 2>$null

$CheckpointFile       = Join-Path $OutputDirectory "checkpoint.json"
$CheckpointBackupFile = Join-Path $OutputDirectory "checkpoint.backup.json"
$CheckpointTempFile   = Join-Path $OutputDirectory "checkpoint.tmp.json"
$ErrorLog             = Join-Path $OutputDirectory "discovery-errors.log"
$HitsCsv              = Join-Path $OutputDirectory "discovery-hits.csv"
$NewHitsCsv         = Join-Path $OutputDirectory "discovery-new-hits.csv"
$RawHitsJsonl       = Join-Path $OutputDirectory "discovery-raw-hit-batches.jsonl"
$SummaryTxt         = Join-Path $OutputDirectory "discovery-summary.txt"
$MetadataDirectory  = Join-Path $OutputDirectory "metadata"

New-Item -ItemType Directory -Path $MetadataDirectory -Force | Out-Null
& attrib.exe -H -S "$MetadataDirectory" 2>$null

# ============================================================================
# Known objects
#
# These are marked in the result file so that unknown but responding objects
# are easy to identify. The list is intentionally limited to already used or
# previously verified objects.
# ============================================================================

$KnownObjects = @{}

function Add-KnownObject {
    param(
        [int]$Mi,
        [int]$Mx,
        [int]$Ox,
        [int]$Os,
        [int]$Vs,
        [string]$Name
    )

    $key = "{0:X2}-{1:X2}-{2:X4}-{3:X2}-{4}" -f $Mi, $Mx, $Ox, $Os, $Vs
    $script:KnownObjects[$key] = $Name
}

# System device
Add-KnownObject 0x01 0x00 0x261E 0x00 1 "Systembetriebsart"
Add-KnownObject 0x01 0x00 0x26B1 0x02 2 "Aussentemperatur"
Add-KnownObject 0x01 0x00 0x259C 0x01 2 "Waermeanforderung Heizung"
Add-KnownObject 0x01 0x00 0x259D 0x01 2 "Waermeanforderung Warmwasser"
Add-KnownObject 0x01 0x00 0x261F 0x02 2 "Plattenwaermetauschertemperatur B2"
Add-KnownObject 0x01 0x00 0x2560 0x02 2 "Pufferspeichertemperatur oben"
Add-KnownObject 0x01 0x00 0x2561 0x02 2 "Pufferspeichertemperatur unten"
Add-KnownObject 0x01 0x00 0x263F 0x00 8 "Fehler-/Warnungsblock"

function Add-KnownHeatingCircuit {
    param([int]$Mx, [string]$Prefix)

    Add-KnownObject 0x02 $Mx 0x2533 0x02 1 "$Prefix Betriebsart Vorgabe"
    Add-KnownObject 0x02 $Mx 0x2582 0x02 1 "$Prefix So/Wi Umschaltung"
    Add-KnownObject 0x02 $Mx 0x257E 0x04 1 "$Prefix Betriebsart aktuell"
    Add-KnownObject 0x02 $Mx 0x257E 0x05 1 "$Prefix Status"
    Add-KnownObject 0x02 $Mx 0x253B 0x02 2 "$Prefix Raumsolltemperatur Komfort"
    Add-KnownObject 0x02 $Mx 0x253A 0x02 2 "$Prefix Raumsolltemperatur Normal"
    Add-KnownObject 0x02 $Mx 0x2539 0x02 2 "$Prefix Raumsolltemperatur Absenk"
    Add-KnownObject 0x02 $Mx 0x2558 0x02 2 "$Prefix Raumsolltemperatur aktuell"
    Add-KnownObject 0x02 $Mx 0x256B 0x02 2 "$Prefix Vorlaufsolltemperatur Komfort"
    Add-KnownObject 0x02 $Mx 0x256A 0x02 2 "$Prefix Vorlaufsolltemperatur Normal"
    Add-KnownObject 0x02 $Mx 0x2569 0x02 2 "$Prefix Vorlaufsolltemperatur Absenk"
    Add-KnownObject 0x02 $Mx 0x252C 0x02 2 "$Prefix Vorlaufsolltemperatur Sonderniveau"
    Add-KnownObject 0x02 $Mx 0x2559 0x02 2 "$Prefix Vorlaufsolltemperatur aktuell"
    Add-KnownObject 0x02 $Mx 0x2507 0x02 2 "$Prefix Vorlaufisttemperatur"
}

Add-KnownHeatingCircuit 0x00 "HK1"
Add-KnownHeatingCircuit 0x01 "HK2"
Add-KnownHeatingCircuit 0x02 "HK3"

# Hot water
Add-KnownObject 0x03 0x00 0x2569 0x02 1 "Status Warmwasser"
Add-KnownObject 0x03 0x00 0x2549 0x02 1 "Warmwasser-Push"
Add-KnownObject 0x03 0x00 0x2539 0x02 2 "WW-Solltemperatur Normal"
Add-KnownObject 0x03 0x00 0x2538 0x02 2 "WW-Solltemperatur Absenk"
Add-KnownObject 0x03 0x00 0x252C 0x02 2 "WW-Solltemperatur aktuell"
Add-KnownObject 0x03 0x00 0x2529 0x02 2 "Warmwassertemperatur aktuell"
Add-KnownObject 0x03 0x00 0x2557 0x02 2 "Ruecklauftemperatur Zirkulation"
Add-KnownObject 0x03 0x00 0x2551 0x02 1 "Pumpe Warmwasser"

# Gateway / network
Add-KnownObject 0x06 0x00 0x2508 0x00 4 "Systemgeraet IP-Adresse"

# WTC
Add-KnownObject 0x09 0x01 0x2639 0x00 1 "Betriebsphase WTC"
Add-KnownObject 0x07 0x00 0x2541 0x00 1 "Betriebsphase Brenner"
Add-KnownObject 0x07 0x00 0x2545 0x00 2 "Vorlaufsolltemperatur"
Add-KnownObject 0x07 0x00 0x2532 0x00 2 "Kesseltemperatur"
Add-KnownObject 0x09 0x01 0x2613 0x02 2 "Volumenstrom VPT"
Add-KnownObject 0x09 0x01 0x2614 0x02 2 "Anlagendruck"
Add-KnownObject 0x07 0x00 0x2533 0x02 2 "Register 167 vermutlich Abgastemperatur"
Add-KnownObject 0x07 0x00 0x2537 0x00 2 "Register 168 vermutlich Ruecklauftemperatur"
Add-KnownObject 0x09 0x01 0x2631 0x02 4 "Waermeleistung VPT"
Add-KnownObject 0x09 0x01 0x2628 0x02 4 "Tageswaermemenge Vortag Gesamt"
Add-KnownObject 0x09 0x01 0x2626 0x02 4 "Tageswaermemenge Vortag Heizbetrieb"
Add-KnownObject 0x09 0x01 0x2627 0x02 4 "Tageswaermemenge Vortag Warmwasser"

# ============================================================================
# Helper functions
# ============================================================================

function Get-ObjectKey {
    param(
        [int]$Mi,
        [int]$Mx,
        [int]$Ox,
        [int]$Os,
        [int]$Vs
    )

    return "{0:X2}-{1:X2}-{2:X4}-{3:X2}-{4}" -f $Mi, $Mx, $Ox, $Os, $Vs
}

function New-GetVg {
    param([PSCustomObject]$Candidate)

    return ("01{0:X2}{1:X2}{2:X4}{3:X2}{4:X4}00" -f `
        $Candidate.MI,
        $Candidate.MX,
        $Candidate.OX,
        $Candidate.OS,
        $Candidate.VS
    ).ToLowerInvariant()
}

function Test-Sentinel {
    param([string]$HexValue)

    if ([string]::IsNullOrWhiteSpace($HexValue)) {
        return $false
    }

    switch ($HexValue.ToLowerInvariant()) {
        "8000"     { return $true }
        "ffff"     { return $true }
        "80000000" { return $true }
        "ffffffff" { return $true }
        default    { return $false }
    }
}

function Get-UnsignedValue {
    param([string]$HexValue)

    if ([string]::IsNullOrWhiteSpace($HexValue)) {
        return $null
    }

    try {
        return [Convert]::ToUInt64($HexValue, 16)
    }
    catch {
        return $null
    }
}

function Initialize-Csv {
    param(
        [string]$Path,
        [string[]]$Columns
    )

    if (-not (Test-Path $Path)) {
        ($Columns -join ";") | Set-Content -Path $Path -Encoding UTF8
    }
}

function Convert-ToCsvField {
    param([object]$Value)

    if ($null -eq $Value) {
        return '""'
    }

    $text = [string]$Value
    return '"' + ($text -replace '"', '""') + '"'
}

function Add-CsvRow {
    param(
        [string]$Path,
        [System.Collections.IDictionary]$Row
    )

    $values = foreach ($column in $Row.Keys) {
        Convert-ToCsvField -Value $Row[$column]
    }

    ($values -join ";") | Add-Content -Path $Path -Encoding UTF8
}

function Save-Checkpoint {
    param(
        [int]$NextCandidateIndex,
        [hashtable]$Stats
    )

    $checkpointObject = [PSCustomObject]@{
        nextCandidateIndex = $NextCandidateIndex
        updated            = (Get-Date).ToString("o")
        stats              = $Stats
    }

    # Write to a temporary file first. This prevents an interrupted write from
    # truncating the only usable checkpoint file to zero bytes.
    $checkpointObject |
        ConvertTo-Json -Depth 6 |
        Set-Content -Path $CheckpointTempFile -Encoding UTF8

    if (Test-Path $CheckpointFile) {
        try {
            if ((Get-Item $CheckpointFile).Length -gt 0) {
                Copy-Item -Path $CheckpointFile -Destination $CheckpointBackupFile -Force
            }
        }
        catch {
            Add-Content -Path $ErrorLog -Value (
                "{0} Checkpoint backup warning: {1}" -f (Get-Date).ToString("o"), $_.Exception.Message
            )
        }
    }

    Move-Item -Path $CheckpointTempFile -Destination $CheckpointFile -Force
}

function Read-ValidCheckpoint {
    param(
        [string[]]$CandidatePaths
    )

    foreach ($path in $CandidatePaths) {
        if (-not (Test-Path $path)) {
            continue
        }

        try {
            if ((Get-Item $path).Length -le 0) {
                continue
            }

            $checkpoint = Get-Content -Path $path -Raw | ConvertFrom-Json

            if ($null -eq $checkpoint.nextCandidateIndex) {
                continue
            }

            return $checkpoint
        }
        catch {
            Add-Content -Path $ErrorLog -Value (
                "{0} Checkpoint read warning for {1}: {2}" -f `
                    (Get-Date).ToString("o"),
                    $path,
                    $_.Exception.Message
            )
        }
    }

    return $null
}

function Invoke-CurlJsonPost {
    param([string]$Payload)

    $payloadFile = Join-Path $env:TEMP "weishaupt-discovery-request.json"

    [System.IO.File]::WriteAllText(
        $payloadFile,
        $Payload,
        [System.Text.UTF8Encoding]::new($false)
    )

    $rawResponse = & curl.exe `
        --http1.1 `
        --silent `
        --show-error `
        --user "${Username}:${Password}" `
        --header "Connection: keep-alive" `
        --header "User-Agent:" `
        --header "Accept:" `
        --header "Referer: $BaseUrl/" `
        --header "Content-Type: application/json" `
        --data-binary "@$payloadFile" `
        $ApiUrl

    if ($LASTEXITCODE -ne 0) {
        throw "curl.exe POST fehlgeschlagen. Exit-Code: $LASTEXITCODE"
    }

    $joined = ($rawResponse -join "`n").Trim()

    if ([string]::IsNullOrWhiteSpace($joined)) {
        throw "Leere Antwort vom Systemgeraet."
    }

    return $joined
}

function Download-MetadataFiles {
    $files = @(
        "/sd/systable.csv",
        "/sd/DLOG_ACT.CSV",
        "/script/einstellung.js",
        "/script/Form_eth_log.js",
        "/script/ajax.js",
        "/script/server.js"
    )

    Write-Host ""
    Write-Host "===== METADATEN-DATEIEN =====" -ForegroundColor Cyan

    foreach ($file in $files) {
        $safeName = ($file.TrimStart("/") -replace "/", "_")
        $target = Join-Path $MetadataDirectory $safeName

        try {
            & curl.exe `
                --silent `
                --show-error `
                --user "${Username}:${Password}" `
                --output $target `
                "$BaseUrl$file"

            if ($LASTEXITCODE -eq 0 -and (Test-Path $target)) {
                & attrib.exe -H -S "$target" 2>$null
                $length = (Get-Item $target).Length
                Write-Host ("{0,-35} -> {1} Bytes" -f $file, $length)
            }
            else {
                Write-Host ("{0,-35} -> Download fehlgeschlagen" -f $file) -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host ("{0,-35} -> Fehler: {1}" -f $file, $_.Exception.Message) -ForegroundColor Red
        }
    }
}

function Build-Candidates {
    $list = New-Object System.Collections.Generic.List[object]

    foreach ($module in $Modules) {
        for ($ox = $OxStart; $ox -le $OxEnd; $ox++) {
            foreach ($os in $SubObjectIndices) {
                foreach ($vs in $ValueSizes) {
                    [void]$list.Add(
                        [PSCustomObject]@{
                            ModuleName = $module.Name
                            MI         = [int]$module.MI
                            MX         = [int]$module.MX
                            OX         = [int]$ox
                            OS         = [int]$os
                            VS         = [int]$vs
                        }
                    )
                }
            }
        }
    }

    return $list
}

function Find-RecoveryIndexFromHitsCsv {
    param(
        [array]$Candidates,
        [string]$Path
    )

    if (-not (Test-Path $Path)) {
        return -1
    }

    try {
        if ((Get-Item $Path).Length -le 0) {
            return -1
        }

        $lastRow = Import-Csv -Path $Path -Delimiter ";" | Select-Object -Last 1

        if ($null -eq $lastRow) {
            return -1
        }

        $targetMi = [Convert]::ToInt32(([string]$lastRow.MI).Replace("0x", ""), 16)
        $targetMx = [Convert]::ToInt32(([string]$lastRow.MX).Replace("0x", ""), 16)
        $targetOx = [Convert]::ToInt32(([string]$lastRow.OX).Replace("0x", ""), 16)
        $targetOs = [Convert]::ToInt32(([string]$lastRow.OS).Replace("0x", ""), 16)
        $targetVs = [int]$lastRow.VS
        $targetModule = [string]$lastRow.Module

        for ($index = $Candidates.Count - 1; $index -ge 0; $index--) {
            $candidate = $Candidates[$index]

            if (
                $candidate.ModuleName -eq $targetModule -and
                $candidate.MI -eq $targetMi -and
                $candidate.MX -eq $targetMx -and
                $candidate.OX -eq $targetOx -and
                $candidate.OS -eq $targetOs -and
                $candidate.VS -eq $targetVs
            ) {
                # Resume one full batch before the last recorded hit. Repeating
                # a small number of read-only requests is harmless and avoids
                # skipping candidates after an interrupted checkpoint write.
                return [Math]::Max(0, $index - ($BatchSize - 1))
            }
        }
    }
    catch {
        Add-Content -Path $ErrorLog -Value (
            "{0} CSV recovery warning: {1}" -f (Get-Date).ToString("o"), $_.Exception.Message
        )
    }

    return -1
}

function Invoke-DiscoveryBatch {
    param(
        [array]$Candidates,
        [hashtable]$Stats
    )

    $capi = [ordered]@{
        NN = $Candidates.Count
    }

    for ($index = 0; $index -lt $Candidates.Count; $index++) {
        $key = "N{0:D2}" -f ($index + 1)
        $capi[$key] = @{
            VG = New-GetVg -Candidate $Candidates[$index]
        }
    }

    $payloadObject = [ordered]@{
        ID   = "12345678"
        SRC  = "DDC"
        CAPI = $capi
    }

    $payload = $payloadObject | ConvertTo-Json -Depth 8 -Compress

    $raw = $null
    $lastError = $null

    for ($attempt = 0; $attempt -le $MaxTransportRetries; $attempt++) {
        try {
            $raw = Invoke-CurlJsonPost -Payload $payload
            break
        }
        catch {
            $lastError = $_.Exception.Message

            if ($attempt -lt $MaxTransportRetries) {
                Start-Sleep -Milliseconds 750
            }
        }
    }

    if ($null -eq $raw) {
        throw $lastError
    }

    $response = $raw | ConvertFrom-Json
    $batchHitRows = @()

    for ($index = 0; $index -lt $Candidates.Count; $index++) {
        $candidate  = $Candidates[$index]
        $key        = "N{0:D2}" -f ($index + 1)
        $requestVg  = $capi[$key].VG
        $responseVg = ""

        if ($null -ne $response.CAPI.$key) {
            $responseVg = [string]$response.CAPI.$key.VG
        }

        if ([string]::IsNullOrWhiteSpace($responseVg) -or $responseVg.Length -lt 16) {
            $Stats.malformedResponses++
            continue
        }

        $command = [Convert]::ToInt32($responseVg.Substring(0, 2), 16)

        if ($command -eq 0x05) {
            $Stats.cmdErrors++
            continue
        }

        if ($command -ne 0x02) {
            $Stats.unexpectedCommands++
            continue
        }

        $mi     = [Convert]::ToInt32($responseVg.Substring(2, 2), 16)
        $mx     = [Convert]::ToInt32($responseVg.Substring(4, 2), 16)
        $ox     = [Convert]::ToInt32($responseVg.Substring(6, 4), 16)
        $os     = [Convert]::ToInt32($responseVg.Substring(10, 2), 16)
        $vs     = [Convert]::ToInt32($responseVg.Substring(12, 4), 16)
        $rawHex = $responseVg.Substring(16)

        $objectKey = Get-ObjectKey -Mi $mi -Mx $mx -Ox $ox -Os $os -Vs $vs
        $knownName = ""

        if ($KnownObjects.ContainsKey($objectKey)) {
            $knownName = $KnownObjects[$objectKey]
        }

        $isKnown    = -not [string]::IsNullOrWhiteSpace($knownName)
        $isSentinel = Test-Sentinel -HexValue $rawHex
        $rawInt     = Get-UnsignedValue -HexValue $rawHex

        $row = [ordered]@{
            Timestamp  = (Get-Date).ToString("s")
            Module     = $candidate.ModuleName
            MI         = ("0x{0:X2}" -f $mi)
            MX         = ("0x{0:X2}" -f $mx)
            OX         = ("0x{0:X4}" -f $ox)
            OS         = ("0x{0:X2}" -f $os)
            VS         = $vs
            RequestVG  = $requestVg
            ResponseVG = $responseVg
            RawHex     = $rawHex
            RawInt     = $rawInt
            Sentinel   = $isSentinel
            Known      = $isKnown
            KnownName  = $knownName
        }

        Add-CsvRow -Path $HitsCsv -Row $row

        if (-not $isKnown) {
            Add-CsvRow -Path $NewHitsCsv -Row $row
            $Stats.newHits++
        }
        else {
            $Stats.knownHits++
        }

        if ($isSentinel) {
            $Stats.sentinelHits++
        }

        $Stats.totalHits++
        $batchHitRows += [PSCustomObject]$row
    }

    if ($batchHitRows.Count -gt 0) {
        [PSCustomObject]@{
            timestamp = (Get-Date).ToString("o")
            request   = $payloadObject
            response  = $response
            hits      = $batchHitRows
        } |
            ConvertTo-Json -Depth 12 -Compress |
            Add-Content -Path $RawHitsJsonl -Encoding UTF8
    }
}

# ============================================================================
# Initialize output and checkpoint
# ============================================================================

$CsvColumns = @(
    "Timestamp",
    "Module",
    "MI",
    "MX",
    "OX",
    "OS",
    "VS",
    "RequestVG",
    "ResponseVG",
    "RawHex",
    "RawInt",
    "Sentinel",
    "Known",
    "KnownName"
)

$Stats = @{
    batchesProcessed  = 0
    candidatesProcessed = 0
    totalHits         = 0
    knownHits         = 0
    newHits           = 0
    sentinelHits      = 0
    cmdErrors         = 0
    malformedResponses = 0
    unexpectedCommands = 0
    transportErrors   = 0
}

$Candidates = Build-Candidates
$TotalCandidates = $Candidates.Count
$TotalBatches = [Math]::Ceiling($TotalCandidates / $BatchSize)

$StartCandidateIndex = 0
$ResumeMode = $false
$ResumeSource = ""

$checkpoint = Read-ValidCheckpoint -CandidatePaths @(
    $CheckpointFile,
    $CheckpointBackupFile
)

if ($null -ne $checkpoint) {
    $StartCandidateIndex = [int]$checkpoint.nextCandidateIndex

    foreach ($key in $Stats.Keys) {
        if ($null -ne $checkpoint.stats.$key) {
            $Stats[$key] = [int64]$checkpoint.stats.$key
        }
    }

    $ResumeMode = $true
    $ResumeSource = "gueltige Checkpoint-Datei"
}
else {
    $recoveredIndex = Find-RecoveryIndexFromHitsCsv -Candidates $Candidates -Path $HitsCsv

    if ($recoveredIndex -ge 0) {
        $StartCandidateIndex = $recoveredIndex
        $ResumeMode = $true
        $ResumeSource = "automatische Wiederherstellung aus discovery-hits.csv"

        Add-Content -Path $ErrorLog -Value (
            "{0} Recovered resume index {1} from discovery-hits.csv because no valid checkpoint was available." -f `
                (Get-Date).ToString("o"),
                $StartCandidateIndex
        )
    }
}

if (-not $ResumeMode) {
    Remove-Item `
        $HitsCsv,
        $NewHitsCsv,
        $RawHitsJsonl,
        $SummaryTxt,
        $ZipOutput,
        $CheckpointFile,
        $CheckpointBackupFile,
        $CheckpointTempFile `
        -ErrorAction SilentlyContinue
}

Initialize-Csv -Path $HitsCsv -Columns $CsvColumns
Initialize-Csv -Path $NewHitsCsv -Columns $CsvColumns

Download-MetadataFiles

Write-Host ""
Write-Host "===== WEISHAUPT READ-ONLY DISCOVERY =====" -ForegroundColor Green
Write-Host "Systemgeraet:        $SystemDevice"
Write-Host "Ausgabeordner:       $OutputDirectory"
Write-Host "Bestaetigte Module:  $($Modules.Count)"
Write-Host "OX-Bereich:          0x$('{0:X4}' -f $OxStart) bis 0x$('{0:X4}' -f $OxEnd)"
Write-Host "OS-Werte:            $($SubObjectIndices -join ', ')"
Write-Host "VS-Werte:            $($ValueSizes -join ', ')"
Write-Host "Batch-Groesse:       $BatchSize"
Write-Host "Pause pro Request:   $DelayMilliseconds ms"
Write-Host "Kandidaten gesamt:   $TotalCandidates"
Write-Host "HTTP-Requests ca.:   $TotalBatches"
Write-Host ""
Write-Host "Es werden ausschliesslich GET-Abfragen gesendet." -ForegroundColor Yellow

if ($ResumeMode) {
    Write-Host ""
    Write-Host "Vorheriger unvollstaendiger Lauf erkannt." -ForegroundColor Cyan
    Write-Host "Wiederaufnahmequelle: $ResumeSource"
    Write-Host "Fortsetzung ab Kandidat: $StartCandidateIndex von $TotalCandidates"
}

$ScanStarted = Get-Date
$consecutiveTransportErrors = 0

try {
    for ($offset = $StartCandidateIndex; $offset -lt $TotalCandidates; $offset += $BatchSize) {
        $lastIndex = [Math]::Min($offset + $BatchSize - 1, $TotalCandidates - 1)
        $batch = @($Candidates[$offset..$lastIndex])

        try {
            Invoke-DiscoveryBatch -Candidates $batch -Stats $Stats
            $consecutiveTransportErrors = 0
        }
        catch {
            $Stats.transportErrors++
            $consecutiveTransportErrors++

            Write-Host ""
            Write-Host ("Transportfehler bei Kandidaten {0}-{1}: {2}" -f `
                ($offset + 1),
                ($lastIndex + 1),
                $_.Exception.Message
            ) -ForegroundColor Red

            if ($consecutiveTransportErrors -ge $AbortAfterConsecutiveTransportErrors) {
                throw "Abbruch nach $consecutiveTransportErrors aufeinanderfolgenden Transportfehlern."
            }
        }

        $Stats.batchesProcessed++
        $Stats.candidatesProcessed += $batch.Count

        $nextIndex = $lastIndex + 1
        Save-Checkpoint -NextCandidateIndex $nextIndex -Stats $Stats

        if (($Stats.batchesProcessed % 100) -eq 0 -or $nextIndex -ge $TotalCandidates) {
            $percent = [Math]::Round(($nextIndex / $TotalCandidates) * 100, 1)

            Write-Host (
                "Fortschritt: {0,6}% | Kandidaten: {1}/{2} | Treffer: {3} | Neu: {4} | CMD_ERROR: {5}" -f `
                    $percent,
                    $nextIndex,
                    $TotalCandidates,
                    $Stats.totalHits,
                    $Stats.newHits,
                    $Stats.cmdErrors
            )
        }

        Start-Sleep -Milliseconds $DelayMilliseconds
    }
}
catch {
    Add-Content -Path $ErrorLog -Value (
        "{0} Scan interrupted: {1}" -f (Get-Date).ToString("o"), $_.Exception.Message
    )

    Write-Host ""
    Write-Host "===== SCAN UNTERBROCHEN =====" -ForegroundColor Yellow
    Write-Host $_.Exception.Message
    Write-Host ""
    Write-Host "Der Fortschritt wurde gespeichert."
    Write-Host "Starte dieselbe CMD-Datei erneut, um fortzusetzen."
    Write-Host ""
    Start-Process explorer.exe -ArgumentList "`"$OutputDirectory`""
    exit 1
}

$ScanFinished = Get-Date
$Duration = New-TimeSpan -Start $ScanStarted -End $ScanFinished

# Completed scan: remove checkpoint files so a future run starts fresh.
Remove-Item $CheckpointFile, $CheckpointBackupFile, $CheckpointTempFile -ErrorAction SilentlyContinue

$summary = @"
===== WEISHAUPT READ-ONLY DISCOVERY SUMMARY =====

Systemgeraet:               $SystemDevice
Start:                      $($ScanStarted.ToString("s"))
Ende:                       $($ScanFinished.ToString("s"))
Laufzeit:                   $($Duration.ToString())

Module:                     $($Modules.Count)
OX-Bereich:                 0x$('{0:X4}' -f $OxStart) bis 0x$('{0:X4}' -f $OxEnd)
OS-Werte:                   $($SubObjectIndices -join ', ')
VS-Werte:                   $($ValueSizes -join ', ')
Batch-Groesse:              $BatchSize
Pause pro Request:          $DelayMilliseconds ms

Kandidaten verarbeitet:     $($Stats.candidatesProcessed)
HTTP-Batches verarbeitet:   $($Stats.batchesProcessed)
Treffer gesamt:             $($Stats.totalHits)
Bekannte Treffer:           $($Stats.knownHits)
Neue Treffer:               $($Stats.newHits)
Sentinel-Treffer:           $($Stats.sentinelHits)
CMD_ERROR-Antworten:        $($Stats.cmdErrors)
Fehlerhafte Antworten:      $($Stats.malformedResponses)
Unerwartete Commands:       $($Stats.unexpectedCommands)
Transportfehler:            $($Stats.transportErrors)

Dateien:
- discovery-hits.csv
- discovery-new-hits.csv
- discovery-raw-hit-batches.jsonl
- discovery-summary.txt
- metadata\
"@

$summary | Set-Content -Path $SummaryTxt -Encoding UTF8

# Make all generated files visible.
& attrib.exe -H -S "$OutputDirectory" 2>$null

Get-ChildItem -LiteralPath $OutputDirectory -Force -Recurse -ErrorAction SilentlyContinue |
    ForEach-Object {
        & attrib.exe -H -S $_.FullName 2>$null
    }

# Create ZIP archive.
if (Test-Path $ZipOutput) {
    Remove-Item $ZipOutput -Force
}

Compress-Archive `
    -Path (Join-Path $OutputDirectory "*") `
    -DestinationPath $ZipOutput `
    -Force

& attrib.exe -H -S "$ZipOutput" 2>$null

Write-Host ""
Write-Host "===== FERTIG =====" -ForegroundColor Green
Write-Host ""
Write-Host $summary
Write-Host "ZIP-Datei:"
Write-Host "  $ZipOutput"
Write-Host ""
Write-Host "Der Ausgabeordner wird jetzt im Explorer geoeffnet." -ForegroundColor Green

Start-Process explorer.exe -ArgumentList "`"$OutputDirectory`""
