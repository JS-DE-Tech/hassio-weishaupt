@echo off
setlocal
cd /d "%~dp0"
echo.
echo Starting the read-only Weishaupt targeted correlation scan.
echo No write commands are sent to the heating system.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0weishaupt-targeted-correlation.ps1"
echo.
pause
